// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef SAIDMSG__MSG__NEW_HPP_
#define SAIDMSG__MSG__NEW_HPP_

#include "saidmsg/msg/detail/new__struct.hpp"
#include "saidmsg/msg/detail/new__builder.hpp"
#include "saidmsg/msg/detail/new__traits.hpp"

#endif  // SAIDMSG__MSG__NEW_HPP_
