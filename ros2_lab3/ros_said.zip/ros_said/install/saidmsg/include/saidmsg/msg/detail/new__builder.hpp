// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from saidmsg:msg/New.idl
// generated code does not contain a copyright notice

#ifndef SAIDMSG__MSG__DETAIL__NEW__BUILDER_HPP_
#define SAIDMSG__MSG__DETAIL__NEW__BUILDER_HPP_

#include "saidmsg/msg/detail/new__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace saidmsg
{

namespace msg
{

namespace builder
{

class Init_New_check
{
public:
  explicit Init_New_check(::saidmsg::msg::New & msg)
  : msg_(msg)
  {}
  ::saidmsg::msg::New check(::saidmsg::msg::New::_check_type arg)
  {
    msg_.check = std::move(arg);
    return std::move(msg_);
  }

private:
  ::saidmsg::msg::New msg_;
};

class Init_New_number
{
public:
  explicit Init_New_number(::saidmsg::msg::New & msg)
  : msg_(msg)
  {}
  Init_New_check number(::saidmsg::msg::New::_number_type arg)
  {
    msg_.number = std::move(arg);
    return Init_New_check(msg_);
  }

private:
  ::saidmsg::msg::New msg_;
};

class Init_New_massage
{
public:
  Init_New_massage()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_New_number massage(::saidmsg::msg::New::_massage_type arg)
  {
    msg_.massage = std::move(arg);
    return Init_New_number(msg_);
  }

private:
  ::saidmsg::msg::New msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::saidmsg::msg::New>()
{
  return saidmsg::msg::builder::Init_New_massage();
}

}  // namespace saidmsg

#endif  // SAIDMSG__MSG__DETAIL__NEW__BUILDER_HPP_
