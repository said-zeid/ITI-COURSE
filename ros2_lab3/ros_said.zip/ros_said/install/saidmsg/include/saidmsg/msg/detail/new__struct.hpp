// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from saidmsg:msg/New.idl
// generated code does not contain a copyright notice

#ifndef SAIDMSG__MSG__DETAIL__NEW__STRUCT_HPP_
#define SAIDMSG__MSG__DETAIL__NEW__STRUCT_HPP_

#include <rosidl_runtime_cpp/bounded_vector.hpp>
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>


#ifndef _WIN32
# define DEPRECATED__saidmsg__msg__New __attribute__((deprecated))
#else
# define DEPRECATED__saidmsg__msg__New __declspec(deprecated)
#endif

namespace saidmsg
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct New_
{
  using Type = New_<ContainerAllocator>;

  explicit New_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->massage = "";
      this->number = 0ll;
      this->check = false;
    }
  }

  explicit New_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : massage(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->massage = "";
      this->number = 0ll;
      this->check = false;
    }
  }

  // field types and members
  using _massage_type =
    std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other>;
  _massage_type massage;
  using _number_type =
    int64_t;
  _number_type number;
  using _check_type =
    bool;
  _check_type check;

  // setters for named parameter idiom
  Type & set__massage(
    const std::basic_string<char, std::char_traits<char>, typename ContainerAllocator::template rebind<char>::other> & _arg)
  {
    this->massage = _arg;
    return *this;
  }
  Type & set__number(
    const int64_t & _arg)
  {
    this->number = _arg;
    return *this;
  }
  Type & set__check(
    const bool & _arg)
  {
    this->check = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    saidmsg::msg::New_<ContainerAllocator> *;
  using ConstRawPtr =
    const saidmsg::msg::New_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<saidmsg::msg::New_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<saidmsg::msg::New_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      saidmsg::msg::New_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<saidmsg::msg::New_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      saidmsg::msg::New_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<saidmsg::msg::New_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<saidmsg::msg::New_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<saidmsg::msg::New_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__saidmsg__msg__New
    std::shared_ptr<saidmsg::msg::New_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__saidmsg__msg__New
    std::shared_ptr<saidmsg::msg::New_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const New_ & other) const
  {
    if (this->massage != other.massage) {
      return false;
    }
    if (this->number != other.number) {
      return false;
    }
    if (this->check != other.check) {
      return false;
    }
    return true;
  }
  bool operator!=(const New_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct New_

// alias to use template instance with default allocator
using New =
  saidmsg::msg::New_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace saidmsg

#endif  // SAIDMSG__MSG__DETAIL__NEW__STRUCT_HPP_
