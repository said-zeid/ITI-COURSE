// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from saidmsg:msg/New.idl
// generated code does not contain a copyright notice
#include "saidmsg/msg/detail/new__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>


// Include directives for member types
// Member `massage`
#include "rosidl_runtime_c/string_functions.h"

bool
saidmsg__msg__New__init(saidmsg__msg__New * msg)
{
  if (!msg) {
    return false;
  }
  // massage
  if (!rosidl_runtime_c__String__init(&msg->massage)) {
    saidmsg__msg__New__fini(msg);
    return false;
  }
  // number
  // check
  return true;
}

void
saidmsg__msg__New__fini(saidmsg__msg__New * msg)
{
  if (!msg) {
    return;
  }
  // massage
  rosidl_runtime_c__String__fini(&msg->massage);
  // number
  // check
}

saidmsg__msg__New *
saidmsg__msg__New__create()
{
  saidmsg__msg__New * msg = (saidmsg__msg__New *)malloc(sizeof(saidmsg__msg__New));
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(saidmsg__msg__New));
  bool success = saidmsg__msg__New__init(msg);
  if (!success) {
    free(msg);
    return NULL;
  }
  return msg;
}

void
saidmsg__msg__New__destroy(saidmsg__msg__New * msg)
{
  if (msg) {
    saidmsg__msg__New__fini(msg);
  }
  free(msg);
}


bool
saidmsg__msg__New__Sequence__init(saidmsg__msg__New__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  saidmsg__msg__New * data = NULL;
  if (size) {
    data = (saidmsg__msg__New *)calloc(size, sizeof(saidmsg__msg__New));
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = saidmsg__msg__New__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        saidmsg__msg__New__fini(&data[i - 1]);
      }
      free(data);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
saidmsg__msg__New__Sequence__fini(saidmsg__msg__New__Sequence * array)
{
  if (!array) {
    return;
  }
  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      saidmsg__msg__New__fini(&array->data[i]);
    }
    free(array->data);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

saidmsg__msg__New__Sequence *
saidmsg__msg__New__Sequence__create(size_t size)
{
  saidmsg__msg__New__Sequence * array = (saidmsg__msg__New__Sequence *)malloc(sizeof(saidmsg__msg__New__Sequence));
  if (!array) {
    return NULL;
  }
  bool success = saidmsg__msg__New__Sequence__init(array, size);
  if (!success) {
    free(array);
    return NULL;
  }
  return array;
}

void
saidmsg__msg__New__Sequence__destroy(saidmsg__msg__New__Sequence * array)
{
  if (array) {
    saidmsg__msg__New__Sequence__fini(array);
  }
  free(array);
}
