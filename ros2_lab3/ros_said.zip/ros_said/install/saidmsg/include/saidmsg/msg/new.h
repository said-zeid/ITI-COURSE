// generated from rosidl_generator_c/resource/idl.h.em
// with input from saidmsg:msg/New.idl
// generated code does not contain a copyright notice

#ifndef SAIDMSG__MSG__NEW_H_
#define SAIDMSG__MSG__NEW_H_

#include "saidmsg/msg/detail/new__struct.h"
#include "saidmsg/msg/detail/new__functions.h"
#include "saidmsg/msg/detail/new__type_support.h"

#endif  // SAIDMSG__MSG__NEW_H_
