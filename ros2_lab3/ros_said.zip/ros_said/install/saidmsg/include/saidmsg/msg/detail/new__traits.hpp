// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from saidmsg:msg/New.idl
// generated code does not contain a copyright notice

#ifndef SAIDMSG__MSG__DETAIL__NEW__TRAITS_HPP_
#define SAIDMSG__MSG__DETAIL__NEW__TRAITS_HPP_

#include "saidmsg/msg/detail/new__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<saidmsg::msg::New>()
{
  return "saidmsg::msg::New";
}

template<>
inline const char * name<saidmsg::msg::New>()
{
  return "saidmsg/msg/New";
}

template<>
struct has_fixed_size<saidmsg::msg::New>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<saidmsg::msg::New>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<saidmsg::msg::New>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // SAIDMSG__MSG__DETAIL__NEW__TRAITS_HPP_
