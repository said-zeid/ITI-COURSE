// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from saidmsg:srv/Firstone.idl
// generated code does not contain a copyright notice

#ifndef SAIDMSG__SRV__DETAIL__FIRSTONE__BUILDER_HPP_
#define SAIDMSG__SRV__DETAIL__FIRSTONE__BUILDER_HPP_

#include "saidmsg/srv/detail/firstone__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace saidmsg
{

namespace srv
{

namespace builder
{

class Init_Firstone_Request_s
{
public:
  explicit Init_Firstone_Request_s(::saidmsg::srv::Firstone_Request & msg)
  : msg_(msg)
  {}
  ::saidmsg::srv::Firstone_Request s(::saidmsg::srv::Firstone_Request::_s_type arg)
  {
    msg_.s = std::move(arg);
    return std::move(msg_);
  }

private:
  ::saidmsg::srv::Firstone_Request msg_;
};

class Init_Firstone_Request_f
{
public:
  Init_Firstone_Request_f()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Firstone_Request_s f(::saidmsg::srv::Firstone_Request::_f_type arg)
  {
    msg_.f = std::move(arg);
    return Init_Firstone_Request_s(msg_);
  }

private:
  ::saidmsg::srv::Firstone_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::saidmsg::srv::Firstone_Request>()
{
  return saidmsg::srv::builder::Init_Firstone_Request_f();
}

}  // namespace saidmsg


namespace saidmsg
{

namespace srv
{

namespace builder
{

class Init_Firstone_Response_avg
{
public:
  Init_Firstone_Response_avg()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::saidmsg::srv::Firstone_Response avg(::saidmsg::srv::Firstone_Response::_avg_type arg)
  {
    msg_.avg = std::move(arg);
    return std::move(msg_);
  }

private:
  ::saidmsg::srv::Firstone_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::saidmsg::srv::Firstone_Response>()
{
  return saidmsg::srv::builder::Init_Firstone_Response_avg();
}

}  // namespace saidmsg

#endif  // SAIDMSG__SRV__DETAIL__FIRSTONE__BUILDER_HPP_
