// generated from rosidl_generator_c/resource/idl.h.em
// with input from saidmsg:srv/Firstone.idl
// generated code does not contain a copyright notice

#ifndef SAIDMSG__SRV__FIRSTONE_H_
#define SAIDMSG__SRV__FIRSTONE_H_

#include "saidmsg/srv/detail/firstone__struct.h"
#include "saidmsg/srv/detail/firstone__functions.h"
#include "saidmsg/srv/detail/firstone__type_support.h"

#endif  // SAIDMSG__SRV__FIRSTONE_H_
