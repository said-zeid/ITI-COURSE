// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from saidmsg:srv/Firstone.idl
// generated code does not contain a copyright notice

#ifndef SAIDMSG__SRV__DETAIL__FIRSTONE__TRAITS_HPP_
#define SAIDMSG__SRV__DETAIL__FIRSTONE__TRAITS_HPP_

#include "saidmsg/srv/detail/firstone__struct.hpp"
#include <rosidl_runtime_cpp/traits.hpp>
#include <stdint.h>
#include <type_traits>

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<saidmsg::srv::Firstone_Request>()
{
  return "saidmsg::srv::Firstone_Request";
}

template<>
inline const char * name<saidmsg::srv::Firstone_Request>()
{
  return "saidmsg/srv/Firstone_Request";
}

template<>
struct has_fixed_size<saidmsg::srv::Firstone_Request>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<saidmsg::srv::Firstone_Request>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<saidmsg::srv::Firstone_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<saidmsg::srv::Firstone_Response>()
{
  return "saidmsg::srv::Firstone_Response";
}

template<>
inline const char * name<saidmsg::srv::Firstone_Response>()
{
  return "saidmsg/srv/Firstone_Response";
}

template<>
struct has_fixed_size<saidmsg::srv::Firstone_Response>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<saidmsg::srv::Firstone_Response>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<saidmsg::srv::Firstone_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<saidmsg::srv::Firstone>()
{
  return "saidmsg::srv::Firstone";
}

template<>
inline const char * name<saidmsg::srv::Firstone>()
{
  return "saidmsg/srv/Firstone";
}

template<>
struct has_fixed_size<saidmsg::srv::Firstone>
  : std::integral_constant<
    bool,
    has_fixed_size<saidmsg::srv::Firstone_Request>::value &&
    has_fixed_size<saidmsg::srv::Firstone_Response>::value
  >
{
};

template<>
struct has_bounded_size<saidmsg::srv::Firstone>
  : std::integral_constant<
    bool,
    has_bounded_size<saidmsg::srv::Firstone_Request>::value &&
    has_bounded_size<saidmsg::srv::Firstone_Response>::value
  >
{
};

template<>
struct is_service<saidmsg::srv::Firstone>
  : std::true_type
{
};

template<>
struct is_service_request<saidmsg::srv::Firstone_Request>
  : std::true_type
{
};

template<>
struct is_service_response<saidmsg::srv::Firstone_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // SAIDMSG__SRV__DETAIL__FIRSTONE__TRAITS_HPP_
