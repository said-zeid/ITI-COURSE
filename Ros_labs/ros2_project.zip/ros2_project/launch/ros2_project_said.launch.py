from launch import LaunchDescription

import launch.actions
import launch_ros.actions


def generate_launch_description():    
    return LaunchDescription([
        
        
        launch_ros.actions.Node(
             package='turtlesim',
             executable='turtlesim_node',
            ),
        launch_ros.actions.Node(
            package='ros2_project',
            executable='node1',
            ),
        launch_ros.actions.Node(
            package='ros2_project',
            executable='node2',
            ),
        

    ])
