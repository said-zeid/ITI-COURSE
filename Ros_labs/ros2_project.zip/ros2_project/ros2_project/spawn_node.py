#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from example_interfaces.msg import Bool
from example_interfaces.msg import Float64
from example_interfaces.srv import AddTwoInts
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
import math
import time
import random
from turtlesim.srv import Spawn
from turtlesim.srv import Kill
from std_srvs.srv import Empty


class spawn_class(Node):
    def __init__(self):
        super().__init__("spawn_turtle")
        self.x = float(random.randint(1, 10))
        self.y = float(random.randint(1, 10))
        #self.x = 8.5
        #self.y = 5.5
        self.name = "said"
        self.finish_sub = self.create_subscription(
            Bool, "finish_topic", self.finish_callback, 10)
        self.call_first_client(self.x, self.y, self.name)

    def finish_callback(self, finish_msg):
        if finish_msg.data == True:
            self.call_third_client(self.name)

    def call_first_client(self, x, y, name):
        client = self.create_client(Spawn, "spawn")
        while client.wait_for_service(0.1) == False:
            self.get_logger().warn("Wait for server node")

        request = Spawn.Request()
        request.x = x
        request.y = y
        request.name = name
        posmsg = Pose()
        posmsg.x = x
        posmsg.y = y
        pos_pub = self.create_publisher(Pose, "abdo", 10)

        pos_pub.publish(posmsg)

        future_obj = client.call_async(request)
        future_obj.add_done_callback(self.future_call_1)

    def future_call_1(self, future_msg):
        self.name = future_msg.result().name
        self.get_logger().info(self.name)

    def call_third_client(self, name):
        client = self.create_client(Kill, "kill")
        while client.wait_for_service(0.5) == False:
            self.get_logger().warn("Wait for server node")

        request = Kill.Request()
        request.name = name

        future_obj = client.call_async(request)
        # self.get_logger().info("hi there 3")
        future_obj.add_done_callback(self.future_call_3)
        time.sleep(1)
        self.x = float(random.randint(1, 10))
        self.y = float(random.randint(1, 10))
        self.call_first_client(self.x, self.y, self.name)

    def future_call_3(self, future_msg):
        pass


def main(args=None):
    rclpy.init(args=args)
    node = spawn_class()
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == "__main__":
    main()
