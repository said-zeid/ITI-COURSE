import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile
from example_interfaces.msg import String


class saidclass(Node):

    def __init__(self):
        super().__init__("state_publisher")
        self.obj_pos = self.create_subscription(
            String, "my_topic", self.call_sub, rclpy.qos.qos_profile_sensor_data)
        self.counter = 0
        print(2)

    def call_sub(self, msg):
        self.counter += 1
        self.get_logger().info("said " + msg.data + str(self.counter))


def main(args=None):
    rclpy.init(args=args)
    node = saidclass()
    rclpy.spin(node)

    rclpy.shutdown()


if __name__ == '__main__':
    main()
