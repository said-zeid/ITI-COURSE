#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from example_interfaces.srv import AddTwoInts
from geometry_msgs.msg import Twist
from example_interfaces.msg import Bool
from example_interfaces.msg import Float64
from turtlesim.msg import Pose
import math
import time
from turtlesim.srv import Spawn
from turtlesim.srv import Kill
from std_srvs.srv import Empty
from math import sqrt, atan2, atan


class control_class(Node):
    def __init__(self):
        super().__init__("contol_turtle")
        self.get_logger().info("Sub_Node_started")
        self.pos_pub = self.create_publisher(Twist, "/turtle1/cmd_vel", 10)
        self.pos_sub = self.create_subscription(
            Pose, "abdo", self.callback, 10)

        self.finish_pub = self.create_publisher(Bool, "finish_topic", 10)
        self.x = 0.0
        self.y = 0.0
        self.yaw = 0.0
        self.vel_msg = Twist()
        self.counter = 0
        self.x0 = 5.5
        self.y0 = 5.5
        self.oldtheta = 0

    def callback(self, posmsg):
        self.x = posmsg.x
        print(self.x)
        self.y = posmsg.y
        print(self.y)
        self.yaw = posmsg.theta
        time.sleep(1)
        self.distance = abs(
            math.sqrt(((self.x-self.x0) ** 2) + ((self.y-self.y0) ** 2)))  # self.x-x0
        theta_s = (atan2((self.y-self.y0), (self.x-self.x0)))
        theta = theta_s-self.oldtheta
        self.oldtheta = theta_s

        self.vel_msg._angular.z = theta
        self.pos_pub.publish(self.vel_msg)
        time.sleep(1)
        self.vel_msg._angular.z = 0.0

        self.vel_msg.linear.x = self.distance
        self.pos_pub.publish(self.vel_msg)
        time.sleep(1)

        self.vel_msg.linear.x = 0.0
        self.vel_msg.linear.y = 0.0
        self.pos_pub.publish(self.vel_msg)

        self.x0 = self.x
        self.y0 = self.y
        finish_msg = Bool()
        finish_msg.data = True
        self.finish_pub.publish(finish_msg)


def main(args=None):

    rclpy.init(args=args)
    node = control_class()
    rclpy.spin(node)

    rclpy.shutdown()


if __name__ == "__main__":
    main()
