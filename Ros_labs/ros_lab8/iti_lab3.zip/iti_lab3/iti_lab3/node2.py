#!/usr/bin/env python3

from example_interfaces.srv import SetBool
import rclpy
from rclpy.node import Node
from example_interfaces.msg import String


class my_node2 (Node):
    def __init__(self):
        super().__init__("node2")
        self.create_subscription(String, "topic1", self.callback2, 10)
        #self.obj_sub = self.create_publisher(String, "number_counter", 10)

        self.massage = String()
        self.counter = 0

        self.get_logger().info("subscriber is started")

    def callback2(self, msg):
        self.massage.data = msg.data
        self.get_logger().info("I heared the msg " + msg.data)


def main(args=None):
    rclpy.init(args=args)
    node2 = my_node2()
    rclpy.spin(node2)

    rclpy.shutdown()


if __name__ == "__main__":
    main()
