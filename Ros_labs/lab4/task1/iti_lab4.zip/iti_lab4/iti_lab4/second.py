#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile
from example_interfaces.msg import String
from turtlesim.msg import Pose


class saidclass2(Node):

    def __init__(self):
        super().__init__("state_publisher")
        self.obj_pos = self.create_subscription(
            Pose(), "turtle1/custom_pose", self.call_sub, rclpy.qos.qos_profile_sensor_data)
        self.counter = 0

    def call_sub(self, msg):
        print(str(msg.x) + "," + str(msg.y))
        #self.get_logger().info(str(msg.x) + "," + str(msg.y))


def main(args=None):
    rclpy.init(args=args)
    node = saidclass2()
    rclpy.spin(node)

    rclpy.shutdown()


if __name__ == '__main__':
    main()
